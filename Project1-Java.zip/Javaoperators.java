class Javaoperators{
  public static void main(String[]args){

    int a = 5;
    String b = "Python";
    System.out.println(a + b);
  }
  
}