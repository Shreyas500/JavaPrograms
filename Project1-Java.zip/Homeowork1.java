import java.util.*;
public class Homeowork1{
    public static void main(String[] args){//acess modifier.
        Scanner sc = new Scanner(System.in);
        System.out.println("Good Morning , Please enter your name!");
        String name = sc.next();
        System.out.println("Hi " + name + ", Please enter your preferred course.");
        String course = sc.next().toUpperCase();
        if(course.equals("JAVA")){
            System.out.println("Good choice , " + course + " is a wonderful course , your course will start in a few weeks");}
        else if(course.equals("PYTHON")){
            
            System.out.println("We are sorry but PYTHON is not available currently , please try later");
          
        }
        else{
          System.out.println("Invalid course , Please enter valid course");
        }
        
          
        
      
    }


  
}