// Write a number , find its factorial and create a function for it to call it anywhere. 
import java.util.*;
public class Factorial_method{
  public static void main(String[] args){
        Scanner sc = new Scanner(System.in); 
      int num = sc.nextInt(); 
      int num1 = 10;
    System.out.println("The factorial of the number you returns is " + factorial(num)); // actual parameter
    System.out.println("The factorial of the number you returns is " + factorial(num1));
  }

  public static int factorial(int num){ // formal parameter

      int i; 
      int fact = 1;
      for(i = 1; i<=num; i++){
          fact= fact*i; 
          
        
      }
      return fact;
    
  }
  
} 