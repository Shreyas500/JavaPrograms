public class Addition{
  // static - for calling
  //void - no returning. 

  // retun? -- returns to the calling of function. 
    public static void main(String[] args){
      int a = 5;
      int b = 4;
      System.out.println(add(a,b));

      
    }

  public static int add(int a , int b){
    int c = a+b;
    return c;

    // if no static then object initialisation 
  }
  
}