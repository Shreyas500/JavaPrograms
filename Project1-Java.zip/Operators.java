class Operators {
  public static void main(String[]args){
    int x = 15;
    int y = 10;
    int z = x+y;
    int a = x-y;
    int b = x*y;
    int c = x/y;
    int m = x%y;
    System.out.println("Sum of x and y is " + z + " Difference is " + a + " Product is " + b + " Division is" + c + " Modulus is " + m);
      
  }
}