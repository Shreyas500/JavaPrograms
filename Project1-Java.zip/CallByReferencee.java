public class CallByReferencee{
  int n=5;

    public static void update(CallByReferencee obj) {//Formal parameter
  //Function definition
      obj.n=obj.n+10;
      System.out.println(obj.n);
    }

  public static void main(String[] args){



    CallByReferencee obj=new CallByReferencee();
    System.out.println(obj.n);

    update(obj); //Actual paramters
    System.out.println(obj.n);
      // call by reference  = all objects are in heap memory that is they are interconnected
    // Change in one results in change in another.
  }
}
