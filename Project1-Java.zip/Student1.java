public class Student1{ // Access modifier  ; public , private , default , protected. 
  String name;
  String grade;
  String schoolName;
  //Behaviours / methods
  //setters and getters
  public void set(String name , String grade , String schoolName){
      this.name = name;
      this.grade = grade;
      this.schoolName = schoolName;

    
  }
  public void print(){
      System.out.println(name);
      System.out.println(grade);
      System.out.println(schoolName);

    
  }
  public static void main(String args[]){
        Student1 s1 = new Student1(); // similar to int a;
        s1.set("Tejas", "10", "Greenwoodhigh");
        s1.print();
      
    
  }
  
  
}