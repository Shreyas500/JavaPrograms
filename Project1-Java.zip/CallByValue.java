class CallByValue{
  public static void main(String args[]){
    int a = 5; // stored in one memory 
    int b = 10;
    System.out.println("Values before update method" a + " " + b );
    update(a,b); // PASSING VALUE
    System.out.println("Values after update method" a + " " + b ); // this will still be 5,10 because the updates a,b only have scope inside the method


    //NOTE: WE HAVE TO PRINT THE METHOD NAME INSTEAD OF A + "" + B. 
  }

  public static void update(int a , int b ){ // these formal parameters are stores in different memories than original a,b and have a scope (only work) inside the method. 
    a+=5;
    b+=5;
    System.out.println("Values inside update method" + a + " " + b); // 10 , 15
    
  }
  
}

//Types of arguement passing

// Call By Value. 
//Call By Reference 