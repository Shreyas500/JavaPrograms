import java.util.Scanner;
  class Method {
    public static void main(String[] args){
      Scanner number = new Scanner(System.in);
      int n = number.nextInt();
      Method m = new Method();

     int result = m.main(n);
      System.out.println(result);
       
      
      
      
    }
    public  int main(int n){
      int b = n*(n+1)/2;
      return b;
      
    }
    
  }
    