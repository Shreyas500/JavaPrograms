import java.util.Scanner;
class Grocerylist {
  public static void main(String[]args){
    String a = " 1) Bread  10rs";
    String b = "2) Eggs  20rs";
    String c = "3) Butter  100rs";
    String d = "4) Jam  50rs";
  Scanner item = new Scanner(System.in);
    System.out.print("Please choose any item you want (use numbering 1- 4 )  : ");
    int z = item.nextInt(); 
    int 
    int sum;
    sum = sum + zamt
    System.out.print("Do you want to continue(1) or exit(2) ? : ");
    int y = item.nextInt();
    if (y==1){
      System.out.println("Please choose any item you want : ");
      int za = item.nextInt();
      System.out.println("Do you want to continue (1) or exit(2) ? : ");
        int zb = item.nextInt();      
    }
    
    if ( zb == 2){
      System.out.println("Thank you for ordering , processing bill.");
      if(z==1)
    }
    
  }
}