import java.util.Scanner;

public class ProductOfDigitsOfSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("no of elements to be added");
        int length = sc.nextInt();
        int[] arr = new int[length];
        for(int i =0;i<length;i++){
            arr[i]= sc.nextInt();
        }
        ProductOfDigitsOfSum obj = new ProductOfDigitsOfSum();
        int ans = obj.productofdigits(arr);
        System.out.println(ans);
        sc.close();

    }
    public int productofdigits(int[] arr) {
        int sum = 0;
        int prod = 1;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        int digit;
        int org = sum;
        while (sum>10) {
            while (sum > 0) {

                digit = sum % 10;
                sum = sum / 10;
                prod *= digit;


            }
            sum  = prod;


    }
        return sum;

    }
}
