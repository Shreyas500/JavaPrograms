public class SortingSelection{
  public static void main(final String[] args){
    final int[] n = {1,2,3,4,6,5,7,6,8,7,9,8};
    final int s = n.length;
    int tmp;
    int minindex;
    for(int i = 0; i<s-1;i++){
      minindex = i;
      for(int j = i+1;j<s;j++){
        if(n[j]<n[minindex]){
          minindex = j;
        }
      }
      tmp = n[i];
      n[i] = n[minindex];
      n[minindex] = tmp;
    }
    for(int i = 0;i<s;i++)
      System.out.println(n[i]);
  }

  
}