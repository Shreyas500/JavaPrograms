//Box class. (length, width, heigth, setDetails, printDetails, volume)

 class Box{

  double length;
  double width; 
  double height; 
  
  public  int volume(){
    int vol = (int)(length * width * height); 
    return vol;
  }

  public void setDetails(double length , double width ,                                 double height ){ // arguements
        
      this.length = length;
      this.width = width; 
      this.height = height; 
  }

  public void setDetails(double length , double width , double height){
      this.length = length; 
      this.width = width; 
      this.height = height; 
  }

  public void printDetails(){

    System.out.println("The length of the box is " + length);
    System.out.println("The width of the box is " + width);
    System.out.println("The height of the box is " + height);
    System.out.println(" Hence from these , the volume is " + 
    vol);
   // sedetails with 2 arguements 
    // arguements arre set when we want to pass values
  } 
  public void setDetails(double value1 , double value2){
    System.out.println("Not allowed. ");
  }
  }
    
  
 
  
