import java.util.Scanner;
 class palindrome{
  public static void main(String[] args){

    Scanner scan = new Scanner(System.in);
    int a = scan.nextInt();
    int b = scan.nextInt();
    int count = 0;
    int i = a; 
    while(i <= b){
        if(ispallindrome(i)==true){
          
          count++;
                                  
                                  
                                  
        
    }
        i++;
    
      
  }
    System.out.println(count);
}
  public static boolean ispallindrome(int num){
        //reversing a numner
    int unit;
    
    int result = 0; 
      while(num>0){
          unit = num%10; 
          num = num/10; 
        result = result*10+unit;
      }
        if (num == result){

          return true;
        }
    else{

      return false;
    }
        
        

    
        
      
    }
          
          
  }
  
  
    
  

