class Box1{
  public static void main(String[] args){
    Box b = new Box();
    b.setDetails(10.5 , 13.4 , 5.1);
    b.printDetails();
    
  }

  
}