import java.util.*;
public class BinarySearch{
  public static void main(String[] args){
    int n[] = {7,15,18,23,25,29,31,37,41};
    Scanner sc = new Scanner(System.in);
    int search = sc.nextInt();
    //9
    int a = Bsearch(search,n);
    if(a==-1)
      System.out.println("ELment not found");
  } 

  public static int Bsearch(int search, int a[]){
    int f = 0;
    int l = a.length-1;
    while(f<=l){
    int mid = ( f+l)/ 2;
    if(a[mid] == search){
      System.out.println("Element found at index" + mid);  return 0;}
      
    else if(a[mid]<search){
      f = mid+1;
    }
    else
      l = mid-1;
    }
    return -1;
  }
}