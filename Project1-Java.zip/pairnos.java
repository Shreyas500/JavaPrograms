import java.util.*;
public class pairnos{
  public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter no of elements in array");
      int n = sc.nextInt();
      System.out.println("Enter sum of numbers to be checked");
      int num = sc.nextInt();
      int arr[] = new int[n];
      int sum = 0;
      int l ;
    int counter = 0;
      for(int i = 0; i<n;i++){
          System.out.println("Enter " + i + " element of array");
          arr[i] = sc.nextInt();
        if(arr[i]==num){
            counter++;
          
        }
      }

      for(int i = 0; i<n-1;i++){
          for(int j = i+1; j<n;j++){
            l = n;
              for(int k= j; k<l;k++){
                  sum+=arr[k] + arr[i];
                  l--;
                  if(sum == num){
                      counter++;
                    
                  }
                  sum = 0;
                
              }
            
              
          }

        
      }
    System.out.println("The no of subsets are " + counter);
     
  }
}