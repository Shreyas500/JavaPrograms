class Box2{
    //Attributes. 
    double length; 
    double width; 
    double height; 

  //Methods


  // same name as that of the class , no return type. --- > Constructor class. 


Box2(){ // contructor class is used to set default values (usually default is 0 but it sets default value. )
  length =2; 
  width = 2; 
  height = 2; 


  
}

Box2(double l, double width, double height){
    length = l;  
    this.width = width; 
    this.height = height;

  
}








  public void set(double l, double width, double height){ // if these parameters had different names we dont have to use (this.) in the method. 
        length = l;  // dont use l = length as if we write that length is assigned to l [ not true]. 
        this.width = width; 
        this.height = height;  // Here as the formal parameter have the same name as the attributes in the class we use  (this . )
    
    // here we are passing values , when the method is called by user , user types the values of len , wid , height and       //then it is passed through method. ]
  }

  
  public void set(double side){ // Method overloading
      length = side;
      width = side;
      height = side;
  
  }


  public void set(double length , double width){
      this.length = length;
      this.width = width; 
      height = 0;

    
  }

  

  public int volume(){ // here static not used because volume changes for each object
    int vol = (int)(length*width*height); 
    return vol; 

    
  }

  public void print(){
    System.out.println("length" + length);
    System.out.println("volume" + volume()); 
    System.out.println("width" + width);
    System.out.println("height" + height);

  
    
  }


  public static void main(String[] args){
    
      Box2 ob = new Box2(5.1,4.2,1.2); // constructor called [box2]
      ob.print();
      ob.set(5.1,4.2,1.2); //has to be called with an object because it is not static. 
      
    
      Boxweight ob1 = new Boxweight();
      ob1.set(2,5,1,3);
      System.out.println(ob1.volume());
      
      // if no values set default is 0 value. 
      
// 2 Constructors with same name in same class is constructor overloading. [ See Student class example]. 
    
  }

  // 2 or more same name methods in a class. differering in number of arguements or type of arguement ---> VERY IMPORTANT CONCEPT ---> METHOD OVERLOADING. 
  





//INHERITANCE --> used to update

// Parent class, super class [Base]. 
// Child class sub class [Derived].

// child class will inherit parent class [ all methods and attributes] + child class also has new properties. 


}


class Boxweight extends Box2{   // Inheritance.
    double weight; 


  Boxweight(){
    super(); // calls Box2 [contructor] from main class . 
    weight = 55; 
  }

  Boxweight(double length, double width , double height , double weight){
    super(length, width, height);
    this.weight = weight;

    
  }

  public void set(double weight, double l , double width , double height ){
      super.set(l, width, height);
      this.weight = weight; 
      
  
    
  }

  public void print(){

      super.print();
      System.out.println("weight" + weight);
    
  }


      
    
  }

class newbox extends Boxweight{
    String colour; 

  newbox(){
      super();
    colour = "red"; 
  }

  newbox(double length , double width , double height, double weight, String colour){
    super(length, width, height , weight);
    this.colour = colour;

    
  }

  public void print(){

    super.print();
    System.out.println("The colour is " + colour);
    
  }

  

  
    
  }

  

// Types of inheritance
//a) Simple inheritance
// b) Multilevel inheritance. 
  
  
