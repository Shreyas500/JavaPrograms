class Studentclass{
    // Attributes. 

  String name; 
  int grade; 
  int id; 

  Studentclass(){
    name = "Tom";
    grade = 9; 
    id = 30; 

    
  }
  Studentclass(String name , int gr , int id){
      this.name = name;
      grade = gr; 
      this.id = id; 

  }



  public void set(String name , int gr , int id){
      this.name = name;
      grade = gr; 
      this.id = id; 
       
  }

  public void print(){ // conformation method. 
      System.out.println("Name " + name);
      System.out.println("Grade " + grade); 
      System.out.println("ID " + id);
    
    
  }
    

  public static void main(String[] args){

      Studentclass object = new Studentclass("Tejas", 9, 25); // contructor called
      object.print();
      
    
  }


  
}