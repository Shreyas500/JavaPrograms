import java.util.Scanner;
class Project3 {
  public static void main(String []args){
      Scanner number = new Scanner(System.in);
      int odd = 0,sum=0;  
      int counter = 0,element;
      while(counter<10){
        element= number.nextInt();
        counter++;
        if(element%2==1){
          odd++;
          sum+=element;
        }
    
        
        
      }
    System.out.println(sum);
    System.out.println(odd);
      
    
  }
  
  
}