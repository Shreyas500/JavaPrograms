
class EMP {

  String name;
  String desig;
  int id;

  EMP() { // Contructor with no arguments
    name = "abc";
    desig = "HOD";
    id = 101;

  }

  EMP(String name, String desig, int id) {
    this.name = name;
    this.desig = desig;
    this.id = id;

  }

  public void setDetails(String name, String desig, int id) { // arguements

    this.name = name;
    this.desig = desig;
    this.id = id;
  }

  public void printDetails() {

    System.out.println("Name is " + name);
    System.out.println("Desig " + desig);
    System.out.println("ID  " + id);

  }

  public void setDetails(String value1, String value2) {
    System.out.println("Not allowed. ");
  }

  public static void main(String[] args) {

    EMP e = new EMP("tejas ", "HOD ", 101);
    e.printDetails();
    company d = new company();
    d.setdetails("morgan stanley", "any", "any1", 1);
    d.printdetails();

  }
}

class company extends EMP {
  String company_name;

  company() {
    super();
    company_name = "";

  }

  public void setdetails(String company_name, String name, String desig, int id) {

    super.setDetails(name, desig, id);
    this.company_name = company_name;

  }

  public void printdetails() {
    super.printDetails();
    System.out.println("Company Name is " + company_name);

  }

}


