class Pattern {
  public static void main(String[] args) {
    System.out.println(
        "   J\ta\tv\t  v  a\n\n   J   a a   v   v  a a\n\nJ  J  aaaaa   V V  aaaaa\n\n JJ  a\t   a   V  a     a");
  }
}

// in terminal - javac Pattern.java
// java Pattern.java
