import java.util.*; 
 class a {
  public static void main(String[] args ){
      int a = 11;
      int b = 10; 
      int z = a+--b;
      System.out.println(z);
      System.out.println(b);
  }
  
}