import java.util.*;
public class TwoDarray{
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter no of rows and columns");
    int r = sc.nextInt();
    int c = sc.nextInt();
    int a[][] = new int[r][c];
    int z[] = new int[r];
    for(int i = 0; i<r;i++){
      for(int j = 0; j<c;j++){
        a[i][j] = sc.nextInt();
        z[i] +=a[i][j];
        
      }
    }

    for(int i = 0; i<r;i++){
      System.out.println(z[i]);
    }
    

    
  }
}