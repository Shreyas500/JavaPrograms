import java.util.*;
public class linearSearch{
    public static void main(String[] args){
          Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
          int s = sc.nextInt();
      
          int a[] = new int[s];

          for(int i = 0; i<s;i++){
              a[i] = sc.nextInt();
              
          }
      System.out.println("Enter search");
      int key = sc.nextInt();
      int flag = 0; 

      for(int i = 0; i<s;i++){
          if(a[i]==key)
              flag = 1; System.out.println("Found");
      }

      if(flag!=1){
        System.out.println("Item not foudn");
      }

      
    }
  
}