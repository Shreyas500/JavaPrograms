class Pattern{
  public static void main(String[]args){
    int counter = 1;
    while(counter<=5){
      System.out.println("*");
      
      
      
    }
  }
}