interface Phone{
        public void alarm();
        public void whatsapp();
        public void musicplayer();
        public void calling();
        
        
      }

class Main implements Phone{

  public static void main(String[] args){
      Phone p = new Main();
     p.calling();
      p.musicplayer();

    
  }

  public void calling(){
      System.out.println("Calling feature");
    
  }

  public void musicplayer(){
      System.out.println("Music play feature");
    
  }
  public void alarm(){
    System.out.println("Alarm feature");
    
    
  }

  public void whatsapp(){
    System.out.println("Whatsapp feature");
  }
  
  
}