class Student {
  String schoolname;
  String name;
  int age;

  public void setdetails(String n, String sn, int a) {
    name = n;
    schoolname = sn;
    age = a;

  }

  public void printdetails() {
    System.out.println("The name of the student is" + name);
    System.out.println("The school" + schoolname);
    System.out.println("The age of student is" + age);
  }

  public static void main(String[] args) {
    Student tejas = new Student();
    tejas.setdetails("Tejas", "greenwoodhigh", 13);
    tejas.printdetails();
  }
}