import java.util.*;
public class Car{
    //Atributes
    String colour;
    String type;
    String model;
    int hp;

  public void input(String c, String t , String m , int h){
        colour = c;
        type = t;
        model = m;
        hp = h;
        
  }

  public void print(){
      String s = " ";
      String c = "colour";
      String t = "type";

      String m = "model";
      for(int i = 0; i<colour.length();i++){
        c = c.concat(s);
      }
      for(int i = 0; i<type.length();i++){
          t = t.concat(s);

        }
      for(int i = 0; i<model.length();i++){
            m = m.concat(s);

      }
    System.out.println(c + t + m + "hp");
      System.out.println(colour + "      " + type + "    " + model + "     " + hp);

//   colour    type  model   hp
//   blue      



  }
  public static void main(String[] args){
      Car obj = new Car(); // Why cant we directly call ? How does object help in calling?
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter all characteristics");
      String colour = sc.nextLine();
      String type = sc.nextLine();
      String model = sc.nextLine();
      int hp = sc.nextInt();
      obj.input(colour , type , model , hp);
      obj.print();
      sc.close();

  }
//      colour
  //    



}