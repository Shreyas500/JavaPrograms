class CallByReference {
  int a = 5;
  int b = 10;
   public static void main(String args[]){
      CallByReference ob = new CallByReference();
      System.out.println("Values before update method" + ob.a + " " + ob.b); 
      update(ob);
      System.out.println("Values after updation" + ob.a + " " + ob.b);
   }

  public static void update(CallByReference ob){ // Callbyreference ob does not create new memory  for objects
    ob.a += 5; 
    ob.b +=5;
    System.out.println("Values inside update method" + ob.a + " " + ob.b);
    
  }
  
}