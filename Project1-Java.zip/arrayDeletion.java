import java.util.*;
public class arrayDeletion{
    public static void main(String[] args){
          Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
          int s = sc.nextInt();

          int a[] = new int[s];

          for(int i = 0; i<s;i++){
              a[i] = sc.nextInt();

          }
        System.out.println("Which index do you want to delete?");
        int ind = sc.nextInt();

        for(int i = ind; i<s-1;i++){
                a[i] = a[i+1];
            
        }
        a[s-1] = 0;
    
    
    
    
    
    
    }}